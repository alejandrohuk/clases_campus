#include <stdio.h>
#include <stdlib.h>
#define CANT 10
int main()
{
    int numero,negativo=0,positivo=0,i;


    for(i=0;i<CANT;i++){
        printf("\nIngrese un numero: ");
        scanf("%d",&numero);
        if(numero>0){
        positivo++;
    }else{
            if(numero<0){
            negativo++;
            }//menor que cero
        }//else
    }//end for
    printf("la cantidad de positivos es: %d y la cantidad de negativos es: %d",positivo,negativo);
    return 0;
}//end main
